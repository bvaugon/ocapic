open Pic18f4620

external init_aff : unit -> unit = "init_aff";;
external print_int : int -> unit = "print_int";;
external print_string : string -> unit = "print_string";;
let stat () =
  Gc.run ();
  print_int (Gc.heap_occupation ());
  for i = 0 to 10000 do () done;
;;

init_aff ();;
stat ();;

class point (x:int) (y:int) =
object(self)
  method get_x = x
  method get_y = y
end
;;

stat ();;

class point_colore c x y =
object(self)
  inherit point x y as super
  method to_string =
    c ^ " " ^ (string_of_int super#get_x) ^ ", " ^ (string_of_int super#get_y)
end
;;

stat ();;

let pc = new point_colore "r" 19 35 in
  stat ();
  print_string pc#to_string;
  for i = 0 to 10000 do () done;
  let p = (pc :> point) in
    stat ();
    print_int p#get_x;
;;

(*
open Pic18f4620

external init_aff : unit -> unit = "init_aff";;
external print_int : int -> unit = "print_int";;
external print_string : string -> unit = "print_string";;
let sleep () =
  for i = 0 to 10000 do for i = 0 to 20 do () done done;
;;

set_bit IRCF1;;
set_bit IRCF0;;
set_bit PLLEN;;

init_aff ();;
print_int 0x4321;;
sleep ();;

class c x y =
object(self)
  val mutable count = 0
  method get_x = x
  method get_y = y
  method get_sum () = count <- succ count ; x + y
  method get_diff () = count <- succ count ; x - y
  method get_count () = count
  method to_string = "(" ^  (string_of_int x) ^ ", " ^ (string_of_int y) ^ ")"
end
;;

Gc.run ();;
print_int (Gc.heap_occupation ());;
sleep ();;

let o = new c 0x19 0x35 in
  print_int o#get_x;
  sleep ();
  print_int o#get_y;
  sleep ();
  print_int (o#get_sum ());
  sleep ();
  print_int (o#get_diff ());
  sleep ();
  print_int (o#get_count ());
  sleep ();
  print_string o#to_string;
;;
*)
