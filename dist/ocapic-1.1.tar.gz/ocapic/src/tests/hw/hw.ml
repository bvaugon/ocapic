open Pic18f4620

module Aff = Lcd.Connect (
struct
  module Pic = Pic18f4620
  let is_8_bits = true
  let e  = LATD0
  let rs = LATD2
  let rw = LATD1
  let port = PORTC
end
);;
open Aff;;

init ();;
config
  ~mode:Cursor_right
  ~disp:On
  ~cursor:Off
  ~blink:Off
  ~lmode:One
  ~font:F5x8
;;

write_string "Hello world ";;
