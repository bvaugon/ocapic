#ifndef _GC
#define _GC

unsigned int alloc_bloc(unsigned int bloc_size, unsigned char tag);

#endif
