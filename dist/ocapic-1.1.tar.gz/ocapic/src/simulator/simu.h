#ifndef SIMU_H
#define SIMU_H

void send_all_proc(char *instr, int size);
void init_simulator(void);

#endif
