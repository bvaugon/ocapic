#include <time.h>
#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/memory.h>

CAMLprim value caml_gc_stat(value v);
CAMLprim value caml_gc_full_major(value v);
CAMLprim value caml_gc_minor(value v);

value caml_gc_run(value unit){
  CAMLparam1(unit);
  caml_gc_minor(Val_unit);
  CAMLreturn(Val_unit);
}

value caml_heap_size(value unit){
  return Val_long(0x7 * 256);
}

value caml_stack_size(value unit){
  return Val_long(0xF57 - 0xE00);
}

value caml_heap_occupation(value unit){
  return Val_long(42);
}

value caml_stack_occupation(value unit){
  return Val_long(42);
}

value caml_running_number(value unit){
  CAMLparam1(unit);
  CAMLlocal1(stat);
  caml_gc_full_major(Val_unit);
  stat = caml_gc_stat(Val_unit);
  CAMLreturn(Field(stat, 3)); /* minor_collection */
}

value caml_random_bits(value unit){
  return Val_long(random() % 65536 - 32768);
}

value caml_random_bool(value unit){
  return Val_long(random() % 2 != 0);
}

value caml_random_round(value unit){
  srandom(time(NULL));
  return Val_unit;
}
