external round : unit -> unit = "caml_random_round"
external bits : unit -> int = "caml_random_bits"
external bool : unit -> bool = "caml_random_bool"

let rec intaux bound =
  let r = bits () in
  let v = r mod bound in
    if r - v > 0x3FFF - bound + 1 then intaux bound else v
;;

let int bound =
  if bound <= 0 then invalid_arg "Random.int" else intaux bound
;;
