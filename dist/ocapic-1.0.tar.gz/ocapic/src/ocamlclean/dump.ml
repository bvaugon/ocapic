exception Exn of string

let parse ic index section =
  try
    let (offset, length) = Index.find_section index section in
      seek_in ic offset;
      (section, Array.init length (fun _ -> input_byte ic))
  with Not_found -> (section, [||])
;;

let parse_beginning ic index =
  let rec compute_min min rest =
    match rest with
      | [] -> min
      | (_, offset, _) :: tl ->
	  if offset < min then compute_min offset tl else compute_min min tl
  in
  let size = compute_min (in_channel_length ic) index in
    seek_in ic 0;
    Array.init size (fun _ -> input_byte ic);
;;

let export oc mem =
  Array.iter (output_byte oc) mem;
;;
