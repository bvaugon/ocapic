let version = "1.0" in
let compile_only = ref false in
let output_file = ref None in
let verbose = ref false in
let spec =
  Arg.align [
    ("-c", Arg.Set compile_only,
     " Compile only");
    ("-o", Arg.String (fun o -> output_file := Some o),
     "<file.asm> Define output file");
    ("-verbose", Arg.Set verbose,
     " Verbose mode");
    ("-version", Arg.Unit (fun () -> print_endline version ; exit 0),
     " Print version and exit");
  ]
in
let usage =
  Printf.sprintf "Usages:\n\
  %s [ OCAMLC_OPTS ] [ OPTIONS ] -c <src.ml> ...\n\
  %s [ OCAMLC_OPTS ] [ OPTIONS ] -c <src.mli> ...\n\
  %s [ OCAMLC_OPTS ] [ BC2ASM_OPTS ] [ OPTIONS ] <src.ml> ...\n\
  %s [ OCAMLC_OPTS ] [ BC2ASM_OPTS ] [ OPTIONS ] <obj.cmo> ...\n\
"
    Sys.argv.(0) Sys.argv.(0) Sys.argv.(0) Sys.argv.(0)
in
let error msg =
  Printf.printf "Error: %s\n" msg;
  Arg.usage spec usage;
  exit 1;
in
let asms = ref [] in
let mls = ref [] in
let cmos = ref [] in
let ocamlc_options = ref [] in
let pic = ref None in
let interp = ref None in
let runtime = ref None in
let stdlib = ref None in
let header = ref None in
let unknow arg =
  let get_arg () =
    incr Arg.current;
    if !Arg.current >= Array.length Sys.argv then
      error ("option `" ^ arg ^ "' needs an argument");
    Some (Sys.argv.(!Arg.current))
  in
    match arg with
      | "-pic"     -> pic := get_arg ()
      | "-interp"  -> interp := get_arg ()
      | "-runtime" -> runtime := get_arg ()
      | "-stdlib"  -> stdlib := get_arg ()
      | "-header"  -> header := get_arg ()
      | _ ->
	  if Filename.check_suffix arg ".asm" then
	    asms := arg :: !asms
	  else if Filename.check_suffix arg ".ml" then
	    mls := arg :: !mls
	  else if Filename.check_suffix arg ".mli" then
	    mls := arg :: !mls
	  else if Filename.check_suffix arg ".cmo" then
	    cmos := arg :: !cmos
	  else
	    ocamlc_options := arg :: !ocamlc_options
in
let execute prog args =
  let cmd = ref "" in
    if prog = Config.ocamlc then
      cmd := !cmd ^ Printf.sprintf "CAMLLIB=%s " (Filename.quote Config.libdir);
    cmd := !cmd ^ (Filename.quote prog);
    List.iter
      (fun arg -> cmd := Printf.sprintf "%s %s" !cmd (Filename.quote arg))
      args;
    if !verbose then Printf.printf "+ %s\n%!" !cmd;
    match Sys.command !cmd with
      | 0 -> ()
      | n -> exit n
in
let nb_arg = Array.length Sys.argv in
  while !Arg.current <> nb_arg do
    try
      Arg.parse_argv Sys.argv spec unknow usage;
    with
      | Arg.Help msg -> Printf.printf "%s" msg; exit 0;
      | Arg.Bad msg ->
	  match Sys.argv.(!Arg.current) with
	    | "-c" | "-o" | "-verbose" | "-version" ->
		Printf.eprintf "%s" msg; exit 2;
	    | arg -> unknow arg
  done;
  asms := List.rev !asms;
  mls := List.rev !mls;
  cmos := List.rev !cmos;
  ocamlc_options := List.rev !ocamlc_options;
  if !compile_only then
    begin
      if !pic <> None     then error "compile only, invalid `-pic' option";
      if !interp <> None  then error "compile only, invalid `-interp' option";
      if !runtime <> None then error "compile only, invalid `-runtime' option";
      if !stdlib <> None  then error "compile only, invalid `-stdlib' option";
      if !header <> None  then error "compile only, invalid `-header' option";
      if !output_file <> None then error "compile only, invalid `-o' option";
      if !asms <> [] then
	error "compile only, don't know what to do with .asm files";
      if !cmos <> [] then
	error "compile only, don't know what to do with .cmo files";
      if !mls = [] then error ".ml or .mli file(s) needed";
      execute Config.ocamlc ("-custom" :: "-c" :: !ocamlc_options @ !mls);
    end
  else
    let ml_not_mli =
      List.filter (fun f -> Filename.check_suffix f ".ml") !mls
    in
    let rec last l =
      match l with
	| [] -> invalid_arg "Ocapic.last"
	| e::[] -> e
	| _::tl -> last tl
    in
    let verbose_opt = if !verbose then [ "-verbose" ] else [] in
      if !cmos = [] && ml_not_mli = [] then error ".ml or .cmo file(s) needed";
      let output_base =
	match !output_file with
	  | None ->
	      if ml_not_mli <> [] then
		Filename.chop_suffix (last ml_not_mli) ".ml"
	      else
		Filename.chop_suffix (last !cmos) ".cmo"
	  | Some f ->
	      if not (Filename.check_suffix f ".asm") then
		error "output filename should end with .asm extension";
	      Filename.chop_suffix f ".asm"
      in
	execute Config.ocamlc
	  ("-custom" :: !ocamlc_options @ verbose_opt @ !cmos @ !mls @
	     [ "-o" ; output_base ]);
	execute Config.ocamlclean
	  (verbose_opt @ [ output_base ; "-o" ; output_base ]);
	execute Config.bc2asm (output_base :: !asms);
;;
