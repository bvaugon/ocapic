let libdir = "/home/benoit/info/ocaml/ocapic/localinst/lib/ocapic"
let ocamlc = "/home/benoit/info/ocaml/install/ocaml-3.12.0.unsave/localinst/bin/ocamlc.opt"
let bc2asm = "/home/benoit/info/ocaml/ocapic/localinst/bin/bc2asm"
let ocamlclean = "/home/benoit/info/ocaml/ocapic/localinst/bin/ocamlclean"
