exception Error

type port = A | B | C | D | E
type bit = B0 | B1 | B2 | B3 | B4 | B5 | B6 | B7
type pin = port * bit
type instr = Write of port * int | Tris of port * int | Sync | Stop

let char_of_port port =
  match port with A -> 'A' | B -> 'B' | C -> 'C' | D -> 'D' | E -> 'E'
;;

let port_of_char c =
  match c with
    | 'A' | 'a' -> A
    | 'B' | 'b' -> B
    | 'C' | 'c' -> C
    | 'D' | 'd' -> D
    | 'E' | 'e' -> E
    | _ -> raise Error
;;

let bit_of_char c =
  match c with
    | '0' -> B0 | '1' -> B1 | '2' -> B2 | '3' -> B3
    | '4' -> B4 | '5' -> B5 | '6' -> B6 | '7' -> B7
    | _ -> raise Error
;;

let char_of_bit b =
  match b with
    | B0 -> '0' | B1 -> '1' | B2 -> '2' | B3 -> '3'
    | B4 -> '4' | B5 -> '5' | B6 -> '6' | B7 -> '7'
;;

let val_of_hex c1 c0 =
  let val_of_char c =
    match c with
      | '0' .. '9' -> int_of_char c - int_of_char '0'
      | 'a' .. 'f' -> int_of_char c - int_of_char 'a' + 10
      | 'A' .. 'F' -> int_of_char c - int_of_char 'A' + 10
      | _ -> raise Error
  in
    val_of_char c1 * 16 + val_of_char c0
;;

let mask_of_bit bit =
  match bit with
    | B0 -> 0b1
    | B1 -> 0b10
    | B2 -> 0b100
    | B3 -> 0b1000
    | B4 -> 0b10000
    | B5 -> 0b100000
    | B6 -> 0b1000000
    | B7 -> 0b10000000
;;

let bit_of_value bit value =
  value land (mask_of_bit bit) <> 0
;;

let pin_of_string str =
  if String.length str <> 2 then raise Error;
  (port_of_char str.[0], bit_of_char str.[1]);
;;

let rec input_instr () =
  let line = read_line () in
  let len = String.length line in
  try
    match line with
      | "SYNC" -> Sync
      | "STOP" -> Stop
      | _ ->
	  if len = 4 then
	    if line.[0] = 'W' then
	      let port = port_of_char line.[1] in
	      let value = val_of_hex line.[2] line.[3] in
		Write (port, value)
	    else if line.[0] = 'T' then
	      let port = port_of_char line.[1] in
	      let value = val_of_hex line.[2] line.[3] in
		Tris (port, value)
	    else
	      raise Error
	  else
	    raise Error
  with Error ->
    Printf.eprintf "Invalid instruction: '%s'\n%!" line;
    input_instr ()
;;
