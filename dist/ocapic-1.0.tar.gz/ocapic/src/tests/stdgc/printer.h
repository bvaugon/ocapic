#ifndef _PRINTER
#define _PRINTER

void print_mem(void);

void print_graph(void);

#endif
