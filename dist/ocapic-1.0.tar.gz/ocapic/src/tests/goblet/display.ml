open Pic18f4620;;
open Types;;

set_bit IRCF1;;
set_bit IRCF0;;
set_bit PLLEN;;

module Disp = Lcd.Connect (
struct
  module Pic = Pic18f4620
  let is_8_bits = true
  let e  = LATA0
  let rs = LATA1
  let rw = LATA3
  let port = PORTB
end
);;
open Disp;;

init ();;
config
  ~mode:Cursor_left
  ~disp:On
  ~cursor:Off
  ~blink:Off
  ~lmode:Two
  ~font:F5x8
;;

let string_of_size s =
  match s with
    | Minus -> "."
    | Small -> "\161"
    | Medium -> "o"
    | Big -> "\219"
;;

let string_of_column c =
  let s = String.create 1 in
    s.[0] <- char_of_int ((int_of_char 'A') + c);
    s
;;

let string_of_line l =
  let s = String.create 1 in
    s.[0] <- char_of_int ((int_of_char '1') + l);
    s
;;

let write_action a =
  clear ();
  home ();
  match a with
    | Add (g, i, j) ->
	if g.color = White then write_string "W" else write_string "B";
	write_string (string_of_size g.size);
	write_string " in ";
	write_string (string_of_column i);
	write_string (string_of_line j);
    | Move (i, j, k, l) ->
	write_string (string_of_column i);
	write_string (string_of_line j);
	write_string " -> ";
	write_string (string_of_column k);
	write_string (string_of_line l);
    | Nothing -> invalid_arg "write_action"
;;

let write_string_at p s =
  set_ddram p;
  write_string s;
;;

let write_string s =
  clear ();
  home ();
  write_string s;
;;
