(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../../LICENCE.                          *)
(*                                                                       *)
(*************************************************************************)

open Pic18f4620;;

set_bit IRCF1;;
set_bit IRCF0;;
set_bit PLLEN;;

module Disp = Lcd.Connect (
struct
  module Pic = Pic18f4620
  let is_8_bits = true
  let e  = LATA0
  let rs = LATA1
  let rw = LATA3
  let port = PORTB
end
);;
open Disp;;

init ();;
config
  ~mode:Cursor_left
  ~disp:On
  ~cursor:Off
  ~blink:Off
  ~lmode:Two
  ~font:F5x8
;;

let write_string_at p s =
  set_ddram p;
  write_string s;
;;

let write_string s =
  clear ();
  home ();
  write_string s;
;;

let write_int n =
  write_string (string_of_int n)
;;
