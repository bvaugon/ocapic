/*************************************************************************/
/*                                                                       */
/*                                OCaPIC                                 */
/*                                                                       */
/*            Benoit Vaugon, Université Pierre et Marie Curie            */
/*                                                                       */
/*    Ce fichier est distribué sous les termes de la licence CeCILL-B    */
/*    décrite dans le fichier ../../../LICENCE.                          */
/*                                                                       */
/*************************************************************************/

#ifndef _GC
#define _GC

unsigned int alloc_bloc(unsigned int bloc_size, unsigned char tag);

#endif
