/*************************************************************************/
/*                                                                       */
/*                                OCaPIC                                 */
/*                                                                       */
/*            Benoit Vaugon, Université Pierre et Marie Curie            */
/*                                                                       */
/*    Ce fichier est distribué sous les termes de la licence CeCILL-B    */
/*    décrite dans le fichier ../../LICENCE.                             */
/*                                                                       */
/*************************************************************************/

#include <caml/mlvalues.h>
#include <stdio.h>
#include <time.h>
#include "shared.h"
#include "simu.h"

#define NB_PORT 5
#define LOWER_PORT 0x0
#define HIGHER_PORT (LOWER_PORT + NB_PORT - 1)
#define LOWER_LAT 0x9
#define HIGHER_LAT (LOWER_LAT + NB_PORT - 1)
#define LOWER_TRIS 0x12
#define HIGHER_TRIS (LOWER_TRIS + NB_PORT - 1)
#define SLEEP_TIME 2500000

static unsigned char *regs;
static int *sync_counter;
static int sem_regs;
static int sem_sync;
static int sem_done;
static int nb_proc;
static int is_slow;

void init_regs(int n, int slow){
  int i;
  regs = alloc_shm(128 * sizeof(unsigned char));
  sync_counter = alloc_shm(sizeof(int));
  *sync_counter = 0;
  is_slow = slow;
  sem_regs = create_sem(1);
  sem_sync = create_sem(1);
  sem_done = create_sem(0);
  nb_proc = n;
  for(i = 0 ; i < 128 ; i ++) regs[i] = 0x00;
  regs[0x71] = 0xFF; // INTCON2
  regs[0x70] = 0xC0; // INTCON3
  regs[0x55] = 0xFF; // T0CON
  regs[0x53] = 0x40; // OSCCON
  regs[0x52] = 0x05; // HLVDCON
  regs[0x50] = 0x1C; // RCON
  regs[0x4B] = 0xFF; // PR2
  regs[0x38] = 0x40; // BAUDCON
  regs[0x34] = 0x07; // CMCON
  regs[0x2C] = 0x02; // TXSTA
  regs[0x22] = 0xFF; // IPR2
  regs[0x1F] = 0xFF; // IPR1
  regs[0x16] = 0x0F; // TRISE
  regs[0x15] = 0xFF; // TRISD
  regs[0x14] = 0xFF; // TRISC
  regs[0x13] = 0xFF; // TRISB
  regs[0x12] = 0xFF; // TRISA
}

void destroy_regs(void){
  destroy_sem(sem_regs);
  destroy_sem(sem_sync);
  destroy_sem(sem_done);
}

void dump_regs(void){
  int i, j;
  P(sem_regs);
  for(i = LOWER_PORT ; i <= HIGHER_PORT ; i ++){
    printf("%c: 0b", 'A' + i);
    for(j = 7 ; j >= 0 ; j --) printf("%d", (regs[i] & (1 << j)) != 0);
    printf("  = %3d  = 0x%02x\n", regs[i], regs[i]);
  }
  V(sem_regs);
}

/******************************/

void send_write(char cmnd, int port, unsigned char val){
  char buf[5];
  buf[0] = cmnd;
  buf[1] = port + 'A';
  if(val / 16 < 10)
    buf[2] = val / 16 + '0';
  else
    buf[2] = val / 16 - 10 + 'A';
  if(val % 16 < 10)
    buf[3] = val % 16 + '0';
  else
    buf[3] = val % 16 - 10 + 'A';
  buf[4] = '\n';
  send_all_proc(buf, 5);
}

void send_write_port(int port, unsigned char val){
  send_write('W', port, val);
}

void send_write_tris(int tris, unsigned char val){
  send_write('T', tris - LOWER_TRIS, val);
}

/**************/

void pic_write_reg_gen(int reg, unsigned char new_val){
  unsigned char old_val = regs[reg];
  if(reg >= LOWER_PORT && reg <= HIGHER_PORT){
    int lat = reg - LOWER_PORT + LOWER_LAT;
    regs[lat] = new_val;
    if(old_val != new_val){
      int tris = reg - LOWER_PORT + LOWER_TRIS;
      unsigned char tris_val = regs[tris];
      if(tris_val == 0xFF){
	char port_c = 'A' + reg - LOWER_PORT;
	fprintf(stderr, "Warning: pic write PORT%c with TRIS%c=0xFF\n",
		port_c, port_c);
      }else{
	int bit;
	unsigned char new_port_val = old_val;
	for(bit = 0 ; bit < 8 ; bit ++){
	  unsigned char mask = 1 << bit;
	  if(!(tris_val & mask)){
	    if(new_val & mask)
	      new_port_val |= mask;
	    else
	      new_port_val &= ~mask;
	  }
	}
	if(new_port_val != old_val){
	  regs[reg] = new_port_val;
	  send_write_port(reg, new_port_val);
	}
      }
    }
  }else if(reg >= LOWER_LAT && reg <= HIGHER_LAT){
    if(old_val != new_val){
      int bit;
      int port = reg - LOWER_LAT + LOWER_PORT;
      int tris = reg - LOWER_LAT + LOWER_TRIS;
      unsigned char old_port_val = regs[port];
      unsigned char new_port_val = old_port_val;
      unsigned char tris_val = regs[tris];
      for(bit = 0 ; bit < 8 ; bit ++){
	unsigned char mask = 1 << bit;
	if(!(tris_val & mask)){
	  if(new_val & mask)
	    new_port_val |= mask;
	  else
	    new_port_val &= ~mask;
	}
      }
      if(old_port_val != new_port_val){
	regs[port] = new_port_val;
	send_write_port(port, new_port_val);
      }
      regs[reg] = new_val;
    }
  }else if(reg >= LOWER_TRIS && reg <= HIGHER_TRIS){
    if(old_val != new_val){
      int bit;
      int port = reg - LOWER_TRIS + LOWER_PORT;
      int lat = reg - LOWER_TRIS + LOWER_LAT;
      unsigned char old_port_val = regs[port];
      unsigned char new_port_val = old_port_val;
      unsigned char lat_val = regs[lat];
      for(bit = 0 ; bit < 8 ; bit ++){
	unsigned char mask = 1 << bit;
	if((old_val & mask) && !(new_val & mask)){
	  if(lat_val & mask)
	    new_port_val |= mask;
	  else
	    new_port_val &= ~mask;
	}
      }
      if(old_port_val != new_port_val){
	regs[port] = new_port_val;
	send_write_port(port, new_port_val);
      }
      send_write_tris(reg, new_val);
      regs[reg] = new_val;
    }
  }else{
    regs[reg] = new_val;
  }
}

/**************/

void pic_write_reg(int reg, unsigned char new_val){
  P(sem_regs);
  pic_write_reg_gen(reg, new_val);
  V(sem_regs);
}

void pic_clear_bit(int reg, int bit){
  P(sem_regs);
  {
    unsigned char old_val = regs[reg];
    unsigned char mask = 1 << bit;
    unsigned char new_val = old_val & ~mask;
    if(reg >= LOWER_PORT && reg <= HIGHER_PORT){
      int lat = reg - LOWER_PORT + LOWER_LAT;
      regs[lat] &= ~mask;
      if(old_val != new_val){
	int tris = reg - LOWER_PORT + LOWER_TRIS;
	unsigned char tris_val = regs[tris];
	if(tris_val & mask){
	  char port_c = 'A' + reg - LOWER_PORT;
	  fprintf(stderr,
		  "Warning: pic clear PORT%c.R%c%d with TRIS%c=0x%02X\n",
		  port_c, port_c, bit, port_c, tris_val);
	}else{
	  regs[reg] = new_val;
	  send_write_port(reg, new_val);
	}
      }
    }else if(reg >= LOWER_LAT && reg <= HIGHER_LAT){
      if(old_val != new_val){
	int port = reg - LOWER_LAT + LOWER_PORT;
	int tris = reg - LOWER_LAT + LOWER_TRIS;
	unsigned char tris_val = regs[tris];
	regs[reg] = new_val;
	if(!(tris_val & mask)){
	  int old_port_val = regs[port];
	  int new_port_val = old_port_val & ~mask;
	  if(old_port_val != new_port_val){
	    regs[port] = new_port_val;
	    send_write_port(port, new_port_val);
	  }
	}
      }
    }else if(reg >= LOWER_TRIS && reg <= HIGHER_TRIS){
      if(old_val != new_val){
	int port = reg - LOWER_TRIS + LOWER_PORT;
	int lat = reg - LOWER_TRIS + LOWER_LAT;
	unsigned char port_val = regs[port];
	unsigned char lat_val = regs[lat];
	if((port_val & mask) != (lat_val & mask)){
	  if(lat_val & mask)
	    port_val |= mask;
	  else
	    port_val &= ~mask;
	  regs[port] = port_val;
	  send_write_port(port, port_val);
	}
	regs[reg] = new_val;
	send_write_tris(reg, new_val);
      }
    }else{
      regs[reg] = new_val;
    }
  }
  V(sem_regs);
}

void pic_set_bit(int reg, int bit){
  P(sem_regs);
  {
    unsigned char old_val = regs[reg];
    unsigned char mask = 1 << bit;
    unsigned char new_val = old_val | mask;
    if(reg >= LOWER_PORT && reg <= HIGHER_PORT){
      int lat = reg - LOWER_PORT + LOWER_LAT;
      regs[lat] |= mask;
      if(old_val != new_val){
	int tris = reg - LOWER_PORT + LOWER_TRIS;
	unsigned char tris_val = regs[tris];
	if(tris_val & mask){
	  char port_c = 'A' + reg - LOWER_PORT;
	  fprintf(stderr, "Warning: pic set PORT%c.R%c%d with TRIS%c=0x%02X\n",
		  port_c, port_c, bit, port_c, tris_val);
	}else{
	  regs[reg] = new_val;
	  send_write_port(reg, new_val);
	}
      }
    }else if(reg >= LOWER_LAT && reg <= HIGHER_LAT){
      if(old_val != new_val){
	unsigned char mask = 1 << bit;
	int port = reg - LOWER_LAT + LOWER_PORT;
	int tris = reg - LOWER_LAT + LOWER_TRIS;
	unsigned char tris_val = regs[tris];
	regs[reg] = new_val;
	if(!(tris_val & mask)){
	  int old_port_val = regs[port];
	  int new_port_val = old_port_val | mask;
	  if(old_port_val != new_port_val){
	    regs[port] = new_port_val;
	    send_write_port(port, new_port_val);
	  }
	}
      }
    }else if(reg >= LOWER_TRIS && reg <= HIGHER_TRIS){
      if(old_val != new_val){
	regs[reg] = new_val;
	send_write_tris(reg, new_val);
      }
    }else{
      regs[reg] = new_val;
    }
  }
  V(sem_regs);
}

/******************************/

value caml_pic_write_reg(value vreg, value vval){
  unsigned int reg = Long_val(vreg);
  unsigned int val = Long_val(vval);
  init_simulator();
  pic_write_reg(reg, val);
  return Val_unit;
}

value caml_pic_clear_bit(value vbit){
  init_simulator();
  P(sem_regs);
  {
    unsigned int reg = Long_val(vbit) & 0x7F;
    unsigned int mask = Long_val(vbit) >> 7;
    pic_write_reg_gen(reg, regs[reg] & ~mask);
  }
  V(sem_regs);
  return Val_unit;
}

value caml_pic_set_bit(value vbit){
  init_simulator();
  P(sem_regs);
  {
    unsigned int reg = Long_val(vbit) & 0x7F;
    unsigned int mask = Long_val(vbit) >> 7;
    pic_write_reg_gen(reg, regs[reg] | mask);
  }
  V(sem_regs);
  return Val_unit;
}

/******************************/

void may_sleep(){
  if(is_slow){
    struct timespec t;
    t.tv_sec  = 0;
    t.tv_nsec = SLEEP_TIME;
    nanosleep(&t, NULL);
  }
}

void synchronize(){
  P(sem_sync);
  *sync_counter = nb_proc;
  V(sem_sync);
  may_sleep();
  send_all_proc("SYNC\n", 5);
  if(nb_proc != 0) P(sem_done);
}

value caml_pic_read_reg(value reg){
  unsigned int val;
  init_simulator();
  synchronize();
  P(sem_regs);
  val = regs[Long_val(reg)];
  V(sem_regs);
  return Val_long(val);
}

value caml_pic_test_bit(value bit){
  unsigned int reg = Long_val(bit) & 0x7F;
  unsigned int mask = Long_val(bit) >> 7;
  unsigned int val;
  init_simulator();
  synchronize();
  P(sem_regs);
  val = (regs[reg] & mask) != 0;
  V(sem_regs);
  return Val_long(val);
}

/******************************/

value caml_pic_tris_of_port(value port_or_bit){
  unsigned int reg = Long_val(port_or_bit) & 0x7F;
  unsigned int mask = Long_val(port_or_bit) >> 7;
  if(reg >= LOWER_PORT && reg <= HIGHER_PORT){
    return Val_long((mask << 7) | (reg + LOWER_TRIS));
  }else if(reg >= LOWER_LAT && reg <= HIGHER_LAT){
    return Val_long((mask << 7) | (reg - LOWER_LAT + LOWER_TRIS));
  }else{
    fprintf(stderr, "Error: tris_of_port(0x%0x): not a port\n", reg);
    return Val_long(LOWER_TRIS);
  }
}

/******************************/

void out_write_port(int port, unsigned char new_val){
  P(sem_regs);
  {
    int tris = port - LOWER_PORT + LOWER_TRIS;
    int tris_val = regs[tris];
    int old_val = regs[port];
    if(tris_val != 0xFF){
      char port_c = 'A' + port - LOWER_PORT;
      fprintf(stderr,
	      "Warning: outside component write PORT%c with TRIS%c=0x%02X\n",
	      port_c, port_c, tris_val);
    }
    if(new_val != old_val){
      regs[port] = new_val;
      send_write_port(port, new_val);
    }
  }
  V(sem_regs);
}

void out_clear_port_bit(int port, int bit){
  P(sem_regs);
  {
    int mask = 1 << bit;
    int tris = port - LOWER_PORT + LOWER_TRIS;
    int tris_val = regs[tris];
    int old_val = regs[port];
    int new_val = old_val & ~mask;
    if(!(tris_val & mask)){
      char port_c = 'A' + port - LOWER_PORT;
      fprintf(stderr,
	"Warning: outside component clear PORT%c.R%c%d with TRIS%c=0x%02X\n",
	      port_c, port_c, bit, port_c, tris_val);
    }
    if(old_val != new_val){
      regs[port] = new_val;
      send_write_port(port, new_val);
    }
  }
  V(sem_regs);
}

void out_set_port_bit(int port, int bit){
  P(sem_regs);
  {
    int mask = 1 << bit;
    int tris = port - LOWER_PORT + LOWER_TRIS;
    int tris_val = regs[tris];
    int old_val = regs[port];
    int new_val = old_val | mask;
    if(!(tris_val & mask)){
      char port_c = 'A' + port - LOWER_PORT;
      fprintf(stderr,
	"Warning: outside component set PORT%c.R%c%d with TRIS%c=0x%02X\n",
	      port_c, port_c, bit, port_c, tris_val);
    }
    if(old_val != new_val){
      regs[port] = new_val;
      send_write_port(port, new_val);
    }
  }
  V(sem_regs);
}

/**************/

void invalid_instr(char *instr){
  fprintf(stderr, "Invalid instruction: '%s'\n", instr);
}

void exec_instr(char *instr, int size){
  if(size < 3){
    invalid_instr(instr);
  }else if((size == 4) &&
	   (instr[0] == 'D' || instr[0] == 'd') &&
	   (instr[1] == 'O' || instr[1] == 'o') &&
	   (instr[2] == 'N' || instr[2] == 'n') &&
	   (instr[3] == 'E' || instr[3] == 'e')){
    P(sem_sync);
    *sync_counter = *sync_counter - 1;
    if(*sync_counter == 0) V(sem_done);
    V(sem_sync);
  }else{
    int port;
    if(instr[1] >= 'A' && instr[1] <= ('A' + HIGHER_PORT - LOWER_PORT)){
      port = instr[1] - 'A' + LOWER_PORT;
    }else if(instr[1] >= 'a' && instr[1] <= ('a' + HIGHER_PORT - LOWER_PORT)){
      port = instr[1] - 'a' + LOWER_PORT;
    }else{
      invalid_instr(instr);
      return;
    }
    switch(instr[0]){
    case 'W':
    case 'w':
      if(size != 4) invalid_instr(instr);
      else{
	int h1, h0;
	char c1 = instr[2], c0 = instr[3];
	if(c1 >= '0' && c1 <= '9') h1 = c1 - '0';
	else if(c1 >= 'A' && c1 <= 'F') h1 = c1 - 'A' + 10;
	else if(c1 >= 'a' && c1 <= 'f') h1 = c1 - 'a' + 10;
	else{
	  invalid_instr(instr);
	  return;
	}
	if(c0 >= '0' && c0 <= '9') h0 = c0 - '0';
	else if(c0 >= 'A' && c0 <= 'F') h0 = c0 - 'A' + 10;
	else if(c0 >= 'a' && c0 <= 'f') h0 = c0 - 'a' + 10;
	else {
	  invalid_instr(instr);
	  return;
	}
	out_write_port(port, 16 * h1 + h0);
      }
    break;
    case 'C':
    case 'c':
      if(size != 3 || instr[2] < '0' || instr[2] > '7') invalid_instr(instr);
      else {
	out_clear_port_bit(port, instr[2] - '0');
      }
    break;
    case 'S':
    case 's':
      if(size != 3 || instr[2] < '0' || instr[2] > '7') invalid_instr(instr);
      else {
	out_set_port_bit(port, instr[2] - '0');
      }
    break;
    default:
      invalid_instr(instr);
    }
  }
}
