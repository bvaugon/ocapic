(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../LICENCE.                             *)
(*                                                                       *)
(*************************************************************************)

let libdir = "/home/benoit/info/ocaml/ocapic/localinst/lib/ocapic"
let ocamlc = "/usr/bin/ocamlc.opt"
let bc2asm = "/home/benoit/info/ocaml/ocapic/localinst/bin/bc2asm"
let ocamlclean = "/home/benoit/info/ocaml/ocapic/localinst/bin/ocamlclean"
