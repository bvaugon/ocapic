(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../LICENCE.                             *)
(*                                                                       *)
(*************************************************************************)

let version = "1.0" in
let pic = ref "18f4620" in
let interp = ref (Config.libdir ^ "/interp.asm") in
let runtime = ref (Config.libdir ^ "/runtime.asm") in
let stdlib = ref (Config.libdir ^ "/stdlib.asm") in
let output = ref None in
let header = ref None in
let verbose = ref false in
let bytecode = ref None in
let externs = ref [] in
let spec =
  Arg.align [
    ("-pic", Arg.Set_string pic,
     "<pic> Define pic (default: 18f4620)");
    ("-o", Arg.String (fun o -> output := Some o),
     "<file.asm> Define output file (default: <bytecode>.asm)");
    ("-header", Arg.String (fun h -> header := Some h),
     "<file.inc> Define pic header file to include");
    ("-interp", Arg.Set_string interp,
     "<file.asm> Define bytecode interpreter");
    ("-stdlib", Arg.Set_string stdlib,
     "<file.asm> Define assembler standard library");
    ("-runtime", Arg.Set_string runtime,
     "<file.asm> Define assembler runtime");
    ("-verbose", Arg.Set verbose,
     " Verbose mode");
    ("-version", Arg.Unit (fun () -> print_endline version ; exit 0),
     " Print version and exit");
  ] in
let usage =
  Printf.sprintf "Usage: %s [ OPTIONS ] <bytecode> [ <externs.asm> ... ]"
    Sys.argv.(0)
in
let error msg =
  Printf.printf "Error: %s\n" msg;
  Arg.usage spec usage;
  exit 1;
in
let unknow arg =
  if Filename.check_suffix arg ".asm" then
    externs := arg :: !externs
  else if !bytecode = None then
    bytecode := Some arg
  else
    error (Printf.sprintf "don't know what to do with: `%s'" arg);
in
  Arg.parse spec unknow usage;
  let bytecode =
    match !bytecode with
      | None -> error "bytecode file undefined";
      | Some bytecode -> bytecode
  in
  let header =
    match !header with
      | None -> "p" ^ !pic ^ ".inc"
      | Some h -> h
  in
  let output =
    match !output with
      | None -> bytecode ^ ".asm"
      | Some o -> o
  in
  let print_include oc = Printf.fprintf oc "        include \"%s\"\n" in
    try
      let ic = open_in_bin bytecode in
      let oc = open_out_bin output in
      let index = Index.parse ic in
      let prims = Prim.parse ic index in
      let code = Code.parse ic index in
      let data = Data.parse ic index in
      let premap = Prim.remap prims code in
	Code.resolve_addr (Prim.length premap) code;
	if !verbose then Data.print stdout data;
	if !verbose then Code.print stdout code;
	Code.check code;
	Printf.fprintf oc "        processor %s\n\n" !pic;
	print_include oc header;
	print_include oc !interp;
	print_include oc !runtime;
	Prim.export oc premap;
	Code.export oc code;
	Data.export oc data;
	List.iter (print_include oc) !externs;
	print_include oc !stdlib;
	Printf.fprintf oc "\n        end\n";
	close_in ic;
	close_out oc;
    with
      | Code.Exn msg | Data.Exn msg | Index.Exn msg | Instr.Exn msg
      | Prim.Exn msg ->
	  Printf.eprintf "Error: %s\n%!" msg;
	  exit 1;
;;
