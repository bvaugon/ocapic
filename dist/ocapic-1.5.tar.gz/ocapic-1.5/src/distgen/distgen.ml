(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../LICENCE.                             *)
(*                                                                       *)
(*************************************************************************)

open Unix
open Printf
open Filename
open Sys

let bufsize = 4096
let distname = "ocapic"
let extra_dirs = [ "dist" ; "etc" ]
let srcs = [
  "bin" ; "configure" ; "INSTALL" ; "lib" ; "LICENCE" ; "LICENCE-en";
  "OCaml_LICENSE" ; "Makefile" ; "man" ; "src" ; "VERSION";
]
  
let mktemp () =
  temp_file "ocapic_" ".tmp"
;;

let mkdir dir =
  printf "mkdir %s\n%!" dir;
  mkdir dir 0o750;
;;

let exec_cmnd cmnd =
  printf "%s\n%!" cmnd;
  let status = command cmnd in
  if status <> 0 then
    failwith (sprintf "Command `%s' exits with status %d" cmnd status);
;;

let ocaml_header_ml = "\
(*************************************************************************)
(*                                                                       *)
(*                           Objective Caml                              *)
(*                                                                       *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt           *)
(*                                                                       *)
(*  Copyright 1996 Institut National de Recherche en Informatique et     *)
(*  en Automatique.  All rights reserved.  This file is distributed      *)
(*  under the terms of the GNU Library General Public License, with      *)
(*  the special exception on linking described in file ../OCaml_LICENSE. *)
(*                                                                       *)
(*************************************************************************)

"

let header = [
  "                                                                       ";
  "                                OCaPIC                                 ";
  "                                                                       ";
  "            Benoit Vaugon, Université Pierre et Marie Curie            ";
  "                                                                       ";
  "    Ce fichier est distribué sous les termes de la licence CeCILL-B    ";
  "    décrite dans le fichier %.                                         ";
  "                                                                       ";
]

let gen_header b m e d =
  let buffer = Buffer.create 100 in
  let line_len = String.length (List.hd header) in
  let licence_path =
    let rec f p n = if n = 0 then p else f ("../" ^ p) (pred n) in
      f "LICENCE" d
  in
  let path_len = String.length licence_path in
  let add_border () =
    Buffer.add_string buffer b;
    for i = 1 to line_len do
      Buffer.add_char buffer m;
    done;
    Buffer.add_string buffer e;
    Buffer.add_char buffer '\n';
  in
  let convert_path l =
    try
      let n = String.index l '%' in
      let startl = String.sub l 0 n in
      let endlen = line_len - n + 1 - path_len in
      if endlen < 0 then failwith "Too big depth";
      let endl = String.sub l (succ n) endlen in
	startl ^ licence_path ^ endl
    with Not_found -> l
  in
  let add_line l =
    Buffer.add_string buffer b;
    Buffer.add_string buffer (convert_path l);
    Buffer.add_string buffer e;
    Buffer.add_char buffer '\n';
  in
    add_border ();
    List.iter add_line header;
    add_border ();
    Buffer.add_char buffer '\n';
    Buffer.contents buffer
;;

type header_t = Sharp | Asm | Ml | C

let make_header ht depth =
  match ht with
    | Sharp -> gen_header "##" '#' "##" depth
    | Asm -> gen_header "; |" '=' "|" depth
    | Ml -> gen_header "(*" '*' "*)" depth
    | C -> gen_header "/*" '*' "*/" depth
;;

let get_header =
  let tbl = Hashtbl.create 10 in
    fun ht depth ->
      try Hashtbl.find tbl (ht, depth) with
	| Not_found ->
	    let header = make_header ht depth in
	      Hashtbl.add tbl (ht, depth) header;
	      header
;;

let rec copy ic oc =
  let buf = String.create bufsize in
  let rec f () =
    let n = input ic buf 0 bufsize in
      if n <> 0 then (
	output oc buf 0 n;
	f ();
      )
  in
    f ();
;;

let move f1 f2 =
  let ic = open_in f1 in
  let oc = open_out f2 in
    copy ic oc;
    close_in ic;
    close_out oc;
;;

let add_header h d f =
  let tmpfile = mktemp () in
    printf "Inserting header in `%s%s'...%!" d f;
    move f tmpfile;
    let ic = open_in tmpfile in
    let oc = open_out f in
      output_string oc h;
      copy ic oc;
      close_in ic;
      close_out oc;
      remove tmpfile;
      printf " done\n%!";
;;

let cut_header sz d f =
  let tmpfile = mktemp () in
    printf "Cutting header of `%s%s'...%!" d f;
    move f tmpfile;
    let ic = open_in tmpfile in
    let oc = open_out f in
      for i = 1 to sz do ignore (input_line ic) done;
      copy ic oc;
      close_in ic;
      close_out oc;
      remove tmpfile;
      printf " done\n%!";
;;

let rec throw_tree cur_path cur_depth subdir =
  let new_path = sprintf "%s%s/" cur_path subdir in
  let new_depth = succ cur_depth in
  let content = readdir subdir in
  let exec f =
    if f = "Makefile" then
      add_header (get_header Sharp cur_depth) new_path f
    else if check_suffix f ".asm" then
      add_header (get_header Asm cur_depth) new_path f
    else if check_suffix f ".ml" || check_suffix f ".mli" then
      if Sys.command (sprintf "grep -q '..%sLICENSE' %s" dir_sep f) = 0 then (
	cut_header 13 new_path f;
	add_header ocaml_header_ml new_path f;
      ) else
	add_header (get_header Ml cur_depth) new_path f
    else if check_suffix f ".c" || check_suffix f ".h" then
      add_header (get_header C cur_depth) new_path f
    else if is_directory f then
      throw_tree new_path new_depth f
  in
    chdir subdir;
    Array.iter exec content;
    chdir parent_dir_name;
;;

let prepare_tree () =
  chdir (concat (concat (dirname argv.(0)) parent_dir_name) "dist");
  exec_cmnd (sprintf "rm -Rf %s" distname);
  mkdir distname;
  List.iter (fun d -> mkdir (concat distname d)) extra_dirs;
  List.iter (fun f -> exec_cmnd (sprintf "cp -R ../%s %s" f distname)) srcs;
;;

let make_tgz () =
  let distnew = sprintf "%s-%s" distname Config.version in
    rename distname distnew;
    exec_cmnd (sprintf "tar zcf %s.tar.gz %s" distnew distnew);
    exec_cmnd (sprintf "rm -Rf %s" distnew);
;;

try
  prepare_tree ();
  throw_tree "" 0 distname;
  make_tgz ();
with exn ->
  eprintf "\n";
  raise exn;
;;
