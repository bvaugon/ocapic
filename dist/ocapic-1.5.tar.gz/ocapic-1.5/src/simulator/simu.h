/*************************************************************************/
/*                                                                       */
/*                                OCaPIC                                 */
/*                                                                       */
/*            Benoit Vaugon, Université Pierre et Marie Curie            */
/*                                                                       */
/*    Ce fichier est distribué sous les termes de la licence CeCILL-B    */
/*    décrite dans le fichier ../../LICENCE.                             */
/*                                                                       */
/*************************************************************************/

#ifndef SIMU_H
#define SIMU_H

void send_all_proc(char *instr, int size);
void init_simulator(void);

#endif
