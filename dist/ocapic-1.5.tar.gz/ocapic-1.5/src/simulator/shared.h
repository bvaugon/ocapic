/*************************************************************************/
/*                                                                       */
/*                                OCaPIC                                 */
/*                                                                       */
/*            Benoit Vaugon, Université Pierre et Marie Curie            */
/*                                                                       */
/*    Ce fichier est distribué sous les termes de la licence CeCILL-B    */
/*    décrite dans le fichier ../../LICENCE.                             */
/*                                                                       */
/*************************************************************************/

#ifndef SHARED_H
#define SHARED_H

int  create_sem(int init);
void destroy_sem(int sem);
void *alloc_shm(size_t size);
void P(int sem);
void V(int sem);

#endif
