(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../../LICENCE.                          *)
(*                                                                       *)
(*************************************************************************)

open Graphics;;

exception Error;;

type port = A | B | C | D | E
type pin = port * int

let char_of_port port =
  match port with A -> 'A' | B -> 'B' | C -> 'C' | D -> 'D' | E -> 'E'
;;

let port_of_char c =
  match c with
    | 'A' -> A | 'B' -> B | 'C' -> C | 'D' -> D | 'E' -> E
    | _ -> raise Error
;;

let num_of_pin pin =
  match pin with
    | (A, 0) -> 1 | (A, 1) -> 2 | (A, 2) -> 3 | (A, 3) -> 4 | (A, 4) -> 5
    | (A, 5) -> 6 | (A, 6) -> 13 | (A, 7) -> 12 | (B, 0) -> 32 | (B, 1) -> 33
    | (B, 2) -> 34 | (B, 3) -> 35 | (B, 4) -> 36 | (B, 5) -> 37 | (B, 6) -> 38
    | (B, 7) -> 39 | (C, 0) -> 14 | (C, 1) -> 15 | (C, 2) -> 16 | (C, 3) -> 17
    | (C, 4) -> 22 | (C, 5) -> 23 | (C, 6) -> 24 | (C, 7) -> 25 | (D, 0) -> 18
    | (D, 1) -> 19 | (D, 2) -> 20 | (D, 3) -> 21 | (D, 4) -> 26 | (D, 5) -> 27
    | (D, 6) -> 28 | (D, 7) -> 29 | (E, 0) -> 7 | (E, 1) -> 8 | (E, 2) -> 9
    | (E, 3) -> 0 | _ -> raise Error
;;

let pin_of_num num =
  match num with
    | 1 -> (A, 0) | 2 -> (A, 1) | 3 -> (A, 2) | 4 -> (A, 3) | 5 -> (A, 4)
    | 6 -> (A, 5) | 13 -> (A, 6) | 12 -> (A, 7) | 32 -> (B, 0) | 33 -> (B, 1)
    | 34 -> (B, 2) | 35 -> (B, 3) | 36 -> (B, 4) | 37 -> (B, 5) | 38 -> (B, 6)
    | 39 -> (B, 7) | 14 -> (C, 0) | 15 -> (C, 1) | 16 -> (C, 2) | 17 -> (C, 3)
    | 22 -> (C, 4) | 23 -> (C, 5) | 24 -> (C, 6) | 25 -> (C, 7) | 18 -> (D, 0)
    | 19 -> (D, 1) | 20 -> (D, 2) | 21 -> (D, 3) | 26 -> (D, 4) | 27 -> (D, 5)
    | 28 -> (D, 6) | 29 -> (D, 7) | 7 -> (E, 0) | 8 -> (E, 1) | 9 -> (E, 2)
    | 0 -> (E, 3) | _ -> raise Error
;;

let pins = Array.make 40 (0, 0);;
let tris = Array.make 40 true;;
let mem_tris = Array.make 40 false;;
let vals = Array.make 40 false;;
let mem_vals = Array.make 40 true;;

let grew = rgb 200 200 200;;
open_graph " 620x230";;
set_window_title "DIP40 simulator";;
display_mode false;;
set_color grew;
fill_rect 0 0 620 230;;
set_color black;;
fill_rect 50 50 520 130;;
for i = 0 to 19 do
  let x1 = (62 + (254 * i) / 10) in
  let x2 = (62 + (254 * i) / 10) in
  let y1 = 38 in
  let y2 = 180 in
  draw_rect x1 y1 12 12;
  draw_rect x2 y2 12 12;
  pins.(i) <- (x1, y1);
  pins.(39-i) <- (x2, y2);
done;;
set_color (rgb 80 80 80);;
fill_circle 68 72 5;;
fill_circle 49 115 8;;
set_color grew;;
fill_rect 40 105 9 20;;
set_color white;;
for i = 0 to 39 do
  try
    let (x, y) = pins.(i) in
    let (port, bit) = pin_of_num i in
    let c = char_of_port port in
      if i < 20 then moveto (x+1) (y + 16) else moveto (x+1) (y - 16);
      draw_string (Printf.sprintf "%c%d" c bit);
  with Error -> ()
done;;
let draw_plus pin d =
  let (x, y) = pins.(pin) in
    draw_poly_line [| (x+3, y+6+d) ; (x+9, y+6+d) |];
    draw_poly_line [| (x+6, y+3+d) ; (x+6, y+9+d) |];
and draw_minus pin d =
  let (x, y) = pins.(pin) in
    draw_poly_line [| (x+3, y+6+d) ; (x+9, y+6+d) |];
in
  draw_plus 10 (16);
  draw_minus 11 (16);
  draw_plus 31 (-16);
  draw_minus 30 (-16);
;;

let draw_arrow pin isin =
  let (px, py) = pins.(pin) in
  let t x y =
    draw_poly_line [| (x, y) ; (x, y+10) |];
    draw_poly_line [| (x-3, y+7) ; (x, y+10) ; (x+3, y+7) |];
  in
  let b x y =
    draw_poly_line [| (x, y) ; (x, y+10) |];
    draw_poly_line [| (x-3, y+3) ; (x, y) ; (x+3, y+3) |];
  in
    set_color grew;
    if pin < 20 then
      fill_rect px (py - 14) 9 12
    else
      fill_rect px (py + 14) 9 12;
    set_color black;
    if pin < 20 then
      (if isin then t else b) (px + 6) (py - 13)
    else
      (if isin then b else t) (px + 6) (py + 15)
;;

let draw_val pin isone =
  let (px, py) = pins.(pin) in
    set_color (if isone then red else white);
    fill_rect (px+1) (py+1) 10 10;
;;

for i = 0 to 39 do
  match i with
    | 10 | 11 | 30 | 31 -> ()
    | _ -> draw_arrow i true ; draw_val i false ;
done;;

let sync_display =
  let sync_mutex = Mutex.create () in
  let sync_check = ref true in
  let rec sync_thread () =
    Mutex.lock sync_mutex;
    let must_sync = !sync_check in
    sync_check := false;
    Mutex.unlock sync_mutex;
    if must_sync then synchronize ();
    Thread.delay 0.1;
    sync_thread ();
  in
  let _ = Thread.create sync_thread () in
    fun () ->
      Mutex.lock sync_mutex;
      sync_check := true;
      Mutex.unlock sync_mutex;
;;

sync_display ();;

while true do
  let line = read_line () in
    try
      begin match line with
	| "SYNC" -> print_endline "DONE"
	| "STOP" -> exit 0
	| _ ->
	    if String.length line <> 4 then raise Error;
	    let port = port_of_char line.[1] in
	    let value =
	      int_of_string (Printf.sprintf "0x%c%c" line.[2] line.[3])
	    in
	      if line.[0] = 'W' then
		for bit = 0 to 7 do
		  let n = num_of_pin (port, bit) in
		    draw_val n (value land (1 lsl bit) <> 0);
		done
	      else if line.[0] = 'T' then
		for bit = 0 to 7 do
		  let n = num_of_pin (port, bit) in
		    draw_arrow n (value land (1 lsl bit) <> 0);
		done
	      else
		raise Error;
	      sync_display ();
      end;
    with Error ->
      Printf.eprintf "Invalid command: %s\n%!" line;
done
