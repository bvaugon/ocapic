(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../LICENCE.                                *)
(*                                                                       *)
(*************************************************************************)

module type P =
sig
  type bit
  type reg
  val write_reg : reg -> int -> unit
  val read_reg : reg -> int
  val set_bit : bit -> unit
  val clear_bit : bit -> unit
  val tris_of_port : reg -> reg
  val tris_of_pin : bit -> bit
end

module type S =
sig
  module Pic : P
  val is_8_bits : bool
  val e : Pic.bit
  val rs : Pic.bit
  val rw : Pic.bit
  val port : Pic.reg
end

module Connect (C : S) =
struct
  open C
  open Pic

  let tris = tris_of_port port;;

  (***)

  let send =
    if is_8_bits then
      fun c ->
	clear_bit rw;
	write_reg tris 0x00;
	write_reg port c;
	set_bit e;
	clear_bit e;
    else
      fun c ->
	clear_bit rw;
	write_reg tris ((read_reg tris) land 0x0F);
	let oldp = read_reg port land 0x0F in
	write_reg port ((c land 0xF0) lor oldp);
	set_bit e;
	clear_bit e;
	write_reg port (((c lsl 4) land 0xF0) lor oldp);
	set_bit e;
	clear_bit e;;

  let receive =
    if is_8_bits then
      fun () ->
	write_reg tris 0xFF;
	set_bit rw;
	set_bit e;
	let res = read_reg port in
	clear_bit e;
	res
    else
      fun () ->
	write_reg tris ((read_reg tris) lor 0xF0);
	set_bit rw;
	set_bit e;
	let tmp = read_reg port land 0xF0 in
	clear_bit e;
	set_bit e;
	let res = (read_reg port lsr 4) lor tmp in
	clear_bit e;
	res;;

  (***)

  let send_data d = set_bit rs ; send d;;

  let receive_data () = set_bit rs ; receive ();;
      
  let send_instr i = clear_bit rs ; send i;;

  let is_busy () = clear_bit rs ; receive () land 0b10000000 <> 0;;

  let get_addr () = clear_bit rs ; receive () land 0b01111111;;

  (***)

  let set_cgram addr =
    if addr < 0 || addr > 0b01000000 then invalid_arg "Lcd.set_cgram";
    send_instr (0b01000000 lor addr);;

  let set_ddram addr =
    if addr < 0 || addr > 0b10000000 then invalid_arg "Lcd.set_ddram";
    send_instr (0b10000000 lor addr);;

  let wait_ready () = while is_busy () do () done;;

  let clear () = send_instr 0b1 ; wait_ready ();;
  
  let home () = send_instr 0b10 ; wait_ready ();;

  (***)

  type direction = int;;
  let left : direction = 0b000;;
  let right : direction = 0b100;;
  
  let shift_cursor  (d : direction) = send_instr (d lor 0b10000);;
  
  let shift_display (d : direction) = send_instr (d lor 0b11000);;

  (***)

  type mode = Cursor_left | Cursor_right | Display_left | Display_right
  type state = On | Off
  type font = F5x8 | F5x10
  type lmode = One | Two

  let config ~mode ~disp ~cursor ~blink ~lmode ~font =
    send_instr (
      match mode with
	| Cursor_left -> 0b100
	| Cursor_right -> 0b110
	| Display_left -> 0b101
	| Display_right -> 0b111
    );
    wait_ready ();
    send_instr (
      0b1000 lor
	(if disp = On then 0b100 else 0b000) lor
	(if cursor = On then 0b010 else 0b000) lor
	(if blink = On then 0b001 else 0b000)
    );
    wait_ready ();
    send_instr (
      0b100000 lor
	(if is_8_bits then 0b10000 else 0b00000) lor
	(if lmode = Two then 0b01000 else 0b00000) lor
	(if font = F5x10 then 0b00100 else 0b00000)
    );
    wait_ready ();
  ;;
  
  let init =
    if is_8_bits then
      fun () ->
	for i = 0 to 1000 do () done;
	clear_bit (tris_of_pin e);
	clear_bit (tris_of_pin rs);
	clear_bit (tris_of_pin rw);
	clear_bit e;
	clear ();
	home ();
    else
      fun () ->
	for i = 0 to 1000 do () done;
	clear_bit (tris_of_pin e);
	clear_bit (tris_of_pin rs);
	clear_bit (tris_of_pin rw);
	clear_bit e;
	clear_bit rs;
	clear_bit rw;
	write_reg tris ((read_reg tris) land 0x0F);
	write_reg port (0x20 lor ((read_reg port) land 0x0F));
	set_bit e;
	clear_bit e;
	clear ();
	home ();;

  (***)

  let write_string str =
    for i = 0 to String.length str - 1 do
      send_data (int_of_char str.[i]);
      wait_ready ();
    done;;

end
