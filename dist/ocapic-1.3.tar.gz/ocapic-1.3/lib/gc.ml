(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../LICENCE.                                *)
(*                                                                       *)
(*************************************************************************)

external run : unit -> unit = "caml_gc_run"
external heap_size : unit -> int = "caml_heap_size"
external stack_size : unit -> int = "caml_stack_size"
external heap_occupation : unit -> int = "caml_heap_occupation"
external stack_occupation : unit -> int = "caml_stack_occupation"
external running_number : unit -> int = "caml_running_number"
