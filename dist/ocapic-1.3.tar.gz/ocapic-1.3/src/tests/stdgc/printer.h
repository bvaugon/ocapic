/*************************************************************************/
/*                                                                       */
/*                                OCaPIC                                 */
/*                                                                       */
/*            Benoit Vaugon, Université Pierre et Marie Curie            */
/*                                                                       */
/*    Ce fichier est distribué sous les termes de la licence CeCILL-B    */
/*    décrite dans le fichier ../../../LICENCE.                          */
/*                                                                       */
/*************************************************************************/

#ifndef _PRINTER
#define _PRINTER

void print_mem(void);

void print_graph(void);

#endif
