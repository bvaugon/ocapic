(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../LICENCE.                             *)
(*                                                                       *)
(*************************************************************************)

let externals_anchor = 0x1600
let heap1_anchor = 0
let max_user_ram = 0xF80
let atom0_location = max_user_ram - 0x22
