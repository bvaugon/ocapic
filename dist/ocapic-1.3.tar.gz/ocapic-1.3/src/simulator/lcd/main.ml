(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../../LICENCE.                          *)
(*                                                                       *)
(*************************************************************************)

open Comm;;

exception Exn

let usage () =
  Printf.eprintf "Usage: %s [COLxLIN] [e=BB] [rs=BB] [rw=BB] [bus=BB]\n%!"
  Sys.argv.(0);
  exit 1;
;;

let check_prefix prefix str =
  let plen = String.length prefix in
    if plen > String.length str then false else
      let rec f i =
	if i = plen then true
	else if Char.lowercase prefix.[i] <> Char.lowercase str.[i] then false
	else f (succ i)
      in
	f 0
;;

let parse_size str =
  try
    let len = String.length str in
    let x_ind = String.index str 'x' in
    let col = String.sub str 0 x_ind in
    let lin = String.sub str (succ x_ind) (len - x_ind - 1) in
      (int_of_string col, int_of_string lin)
  with Not_found | Invalid_argument _ | Failure _ -> raise Exn
;;

let e = ref (A, B0) in
let rs = ref (A, B1) in
let rw = ref (A, B2) in
let bus = ref B in
let size = ref (20, 4) in
let nb_arg = Array.length Sys.argv in
  for i = 1 to nb_arg - 1 do
    let arg = Sys.argv.(i) in
      try
	let len = String.length arg in
	  if check_prefix "e=r" arg && len = 5 then
	    e := pin_of_string (String.sub arg 3 2)
	  else if check_prefix "rs=r" arg && len = 6 then
	    rs := pin_of_string (String.sub arg 4 2)
	  else if check_prefix "rw=r" arg && len = 6 then
	    rw := pin_of_string (String.sub arg 4 2)
	  else if check_prefix "bus=port" arg && len = 9 then
	    bus := port_of_char arg.[8]
	  else
	    size := parse_size arg;
      with Comm.Error | Exn ->
	Printf.eprintf "Error: don't know what to do with: '%s'\n%!" arg;
	usage ();
  done;
  try
    Display.init_display (fst !size) (snd !size);
    Proto.loop !e !rs !rw !bus;
  with Display.Exn msg ->
    Printf.eprintf "Error: %s\n%!" msg;
    usage ();
;;
