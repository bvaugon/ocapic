(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*            Benoit Vaugon, Université Pierre et Marie Curie            *)
(*                                                                       *)
(*    Ce fichier est distribué sous les termes de la licence CeCILL-B    *)
(*    décrite dans le fichier ../../../LICENCE.                          *)
(*                                                                       *)
(*************************************************************************)

open Printf
open Comm

type display_mode = On | Off
type cursor_mode = Show | Hide | Blink
type line_mode = One | Two
type bus_mode = Height | Four
type direction = Left | Right
type font = F5x8 | F5x11

let verbose = false
let print = if verbose then prerr_endline else (fun _ -> ())
  
let ddram = Array.make 104 ' '
let cgrom = Cgrom.parse ()
let cgram = Array.init 8 (fun _ -> Array.make_matrix 8 5 false)
let ddram_addr = ref 0
let cgram_addr = ref 0

let cursor_mode = ref Hide
let entry_mode_incr = ref Right
let shift_display = ref false
let display_mode = ref On
let line_mode = ref One
let font = ref F5x8
let bus_mode = ref Height
  
let display () =
  if !display_mode = On then
    let matrix =
      (Array.init 40 (fun i -> Array.init 2
			(fun j -> cgrom.(int_of_char ddram.(i + 64 * j)))))
    in
      begin match !cursor_mode with
	| Hide -> ()
	| Show ->
	    begin try
	      let i = !ddram_addr mod 64 in
	      let j = !ddram_addr / 64 in
	      let old_m = matrix.(i).(j) in
	      let m =
		Array.init 8 (fun i -> Array.init 5 (fun j -> old_m.(i).(j)))
	      in
		for j = 0 to 4 do
		  m.(7).(j) <- true;
		done;
		matrix.(i).(j) <- m;
	    with Invalid_argument "index out of bounds" -> () end
	| Blink ->
	    begin try
	      let i = !ddram_addr mod 64 in
	      let j = !ddram_addr / 64 in
	      let old_m = matrix.(i).(j) in
	      let m =
		Array.init 8 (fun i -> Array.init 5 (fun j -> old_m.(i).(j)))
	      in
		for j = 0 to 4 do
		  m.(0).(j) <- true;
		  m.(7).(j) <- true;
		done;
		for i = 1 to 6 do
		  m.(i).(0) <- true;
		  m.(i).(4) <- true;
		done;
		matrix.(i).(j) <- m;
	    with Invalid_argument "index out of bounds" -> () end
      end;
      Display.show matrix;
;;

let clear () =
  print "clear()";
  Array.fill ddram 0 (Array.length ddram) ' ';
  ddram_addr := 0;
  cursor_mode := Hide;
  entry_mode_incr := Right;
  display ();
;;

let home () =
  print "home()";
  ddram_addr := 0;
  display ();
;;

let entry_mode_set id sh =
  print (sprintf "entry_mode_set( I/D = %b , SH = %b )" id sh);
  entry_mode_incr := if id then Right else Left;
  shift_display := sh;
;;

let display_onoff_control d c b =
  print (sprintf "display_onoff_control( D = %b , C = %b , B = %b )" d c b);
  display_mode := if d then On else Off;
  cursor_mode := if c then if b then Blink else Show else Hide;
  display ();
;;

let cursor_or_display_shift sc rl =
  print (sprintf "cursor_or_display_shift( S/C = %b , R/L = %b )" sc rl);
  begin match rl, sc with
    | true, false ->
	let ddram_addr0 = succ !ddram_addr in
	let ddram_addr1 =
	  if !line_mode = One then
	    if ddram_addr0 > 79 then 0 else ddram_addr0
	  else
	    if ddram_addr0 > 103 then 0
	    else if ddram_addr0 > 63 then ddram_addr0
	    else if ddram_addr0 > 39 then 52
	    else ddram_addr0
	in
	  ddram_addr := ddram_addr1;
    | false, false ->
	let ddram_addr0 = pred !ddram_addr in
	let ddram_addr1 =
	  if !line_mode = One then
	    if ddram_addr0 < 0 then 79 else ddram_addr0
	  else
	    if ddram_addr0 < 0 then 103
	    else if ddram_addr0 < 40 then ddram_addr0
	    else if ddram_addr0 < 64 then 39
	    else ddram_addr0
	in
	  ddram_addr := ddram_addr1
    | true, true ->
	let ddram103 = ddram.(103) in
	  for i = 102 downto 0 do
	    ddram.(succ i) <- ddram.(i);
	  done;
	  ddram.(0) <- ddram103;
    | false, true ->
	let ddram0 = ddram.(0) in
	  for i = 0 to 102 do
	    ddram.(i) <- ddram.(succ i);
	  done;
	  ddram.(103) <- ddram0;
  end;
  display ();
;;

let function_set dl n f =
  print (sprintf "function_set( DL = %b , N = %b , F = %b )" dl n f);
  bus_mode := if dl then Height else Four;
  line_mode := if n then Two else One;
  font := if f then F5x11 else F5x8;
;;

let set_cgram_address addr =
  print (sprintf "set_cgram_address(%02x)" addr);
  cgram_addr := addr;
;;

let set_ddram_address addr =
  print (sprintf "set_ddram_address(%02x)" addr);
  ddram_addr := addr;
  display ();
;;

let send bus_low bus_port value =
  printf "W%c%02x\n%!" (Comm.char_of_port bus_port) (
    match !bus_mode with
      | Height -> value
      | Four ->
	  if bus_low > 0x0F then
	    (bus_low land 0x0F) lor (value land 0xF0)
	  else
	    bus_low lor ((value lsl 4) land 0xF0)
  )
;;

let read_busy_flag_and_address bus_low bus_port =
  print "read_busy_flag_and_address()";
  send bus_low bus_port !ddram_addr;
;;

let write_data_to_ram data =
  print (sprintf "write_data_to_ram(%c)" (char_of_int data));
  ddram.(!ddram_addr) <- char_of_int data;
  cursor_or_display_shift !shift_display (!entry_mode_incr = Right);
;;

let read_data_from_ram bus_low bus_port =
  print "read_data_from_ram()";
  send bus_low bus_port (int_of_char ddram.(!ddram_addr));
;;

let exec_8bit rs rw bus bus_port =
  let bus_bit bit = ((1 lsl bit) land bus) <> 0 in
    match rs, rw with
      | false, false ->
	  if bus = 0 then ()
	  else if bus = 1 then clear ()
	  else if bus = 2 || bus = 3 then home ()
	  else if bus < 8 then entry_mode_set (bus_bit 1) (bus_bit 0)
	  else if bus < 16 then
	    display_onoff_control (bus_bit 2) (bus_bit 1) (bus_bit 0)
	  else if bus < 32 then cursor_or_display_shift (bus_bit 3) (bus_bit 2)
	  else if bus < 64 then function_set (bus_bit 4) (bus_bit 3) (bus_bit 2)
	  else if bus < 128 then set_cgram_address (bus land 0b111111)
	  else set_ddram_address (bus land 0b1111111)
      | false, true -> read_busy_flag_and_address bus bus_port
      | true, false -> write_data_to_ram bus
      | true, true -> read_data_from_ram bus bus_port
;;

let exec_4bit =
  let mem_bus = ref (-1) in
    fun rs rw bus bus_port ->
      if rw then (
	if !mem_bus = -1 then (
	  mem_bus := 0;
	  exec_8bit rs rw ((bus land 0x0F) lor 0xF0) bus_port;
	) else (
	  mem_bus := -1;
	  exec_8bit rs rw (bus land 0x0F) bus_port;
	)
      ) else (
	let old_bus = !mem_bus in
	  if old_bus = -1 then mem_bus := bus
	  else (
	    mem_bus := -1;
	    exec_8bit rs rw ((old_bus land 0xF0) lor (bus lsr 4))
	      bus_port;
	  )
      )
;;

let loop (e_port, e_bit) (rs_port, rs_bit) (rw_port, rw_bit) bus_port =
  let rec f old_e e rs rw bus =
    if not old_e && e then
      begin match !bus_mode with
	| Height -> exec_8bit rs rw bus bus_port;
	| Four -> exec_4bit rs rw bus bus_port;
      end;
    begin match input_instr () with
      | Write (port, value) ->
	  let n_e = if port = e_port then bit_of_value e_bit value else e in
	  let n_rs = if port = rs_port then bit_of_value rs_bit value else rs in
	  let n_rw = if port = rw_port then bit_of_value rw_bit value else rw in
	  let n_bus = if port = bus_port then value else bus in
	    f e n_e n_rs n_rw n_bus
      | Tris (_, _) -> f e e rs rw bus
      | Sync -> printf "DONE\n%!" ; f e e rs rw bus
      | Stop -> ()
    end;
  in
    f false false false false 0
;;
